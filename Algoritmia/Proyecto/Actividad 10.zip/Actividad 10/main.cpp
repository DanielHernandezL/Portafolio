#include <iostream>
#include "menu.hpp"
using namespace std;

int main(){

    menu_videogames();

    
    return 0;
}


//;C:\Users\GATEWAY\AppData\Local\Programs\Microsoft VS Code\bin